package com.rabobank.transaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RbFailedTransactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(RbFailedTransactionApplication.class, args);
	}

}
