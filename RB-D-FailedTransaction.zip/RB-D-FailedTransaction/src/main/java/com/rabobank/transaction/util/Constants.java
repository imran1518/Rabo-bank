package com.rabobank.transaction.util;

public class Constants {

 public static final String METHOD_STARTS = "method in - ";
 
 public static final String METHOD_ENDS = "method end - ";
 
 public static final String CSV_NAME = "records.csv";
 
 public static final String XML_NAME = "records.xml";
 
 public static final String EXCEPTION_OCCURRED = "Exception occurred in - ";
 
 public static final String LOCATION = "RB-D-FailedTransaction";
}
